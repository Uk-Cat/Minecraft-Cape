package net.minecraftcapes.mixin.vanilla;

import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_591.class)
public class MixinPlayerEarsModel {

    @Inject(method = "createEarsLayer", at = @At("RETURN"), cancellable = true)
    private static void minecraftcapes$createEarsLayer(CallbackInfoReturnable<class_5607> cir) {
        class_5609 mesh = new class_5609();
        class_5610 root = mesh.method_32111();

        root.method_32117(
                "left_ear",
                class_5606.method_32108()
                        .method_32101(0, 0)
                        .method_32098(-1.0F, -2.0F, -1.0F, 3.0F, 5.0F, 1.0F, new class_5605(1.0F, 1.0F, 0.2F)),
                class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        root.method_32117(
                "right_ear",
                class_5606.method_32108()
                        .method_32101(0, 0)
                        .method_32098(-1.0F, -2.0F, -1.0F, 3.0F, 5.0F, 1.0F, new class_5605(1.0F, 1.0F, 0.2F))
                        .method_32106(true),
                class_5603.method_32090(0.0F, 0.0F, 0.0F)
        );

        cir.setReturnValue(class_5607.method_32110(mesh, 14, 7));
    }
}
