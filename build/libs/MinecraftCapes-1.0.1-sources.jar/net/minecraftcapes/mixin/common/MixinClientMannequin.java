package net.minecraftcapes.mixin.common;

import net.minecraft.class_11903;
import net.minecraft.class_310;
import net.minecraft.class_8685;
import net.minecraftcapes.player.DownloadManager;
import net.minecraftcapes.player.PlayerHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

@Mixin(class_11903.class)
public class MixinClientMannequin {

    @Inject(method = "updateSkin", at = @At("RETURN"))
    private void minecraftcapes$updateSkin(CallbackInfo ci) {
        UUID uuid = class_310.method_1551().method_1548().method_44717();
        PlayerHandler handler = PlayerHandler.getOrCreate(uuid);
        if (!handler.hasInfo()) {
            DownloadManager.prepareDownload(handler);
        }
    }

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void minecraftcapes$getSkin(CallbackInfoReturnable<class_8685> cir) {
        UUID uuid = class_310.method_1551().method_1548().method_44717();
        PlayerHandler handler = PlayerHandler.getOrCreate(uuid);
        if (handler.hasInfo()) {
            cir.setReturnValue(handler.getSkin(cir.getReturnValue()));
        }
    }
}
