package net.minecraftcapes.mixin.common;

import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_972;
import net.minecraftcapes.player.ExtendedRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_972.class)
public class MixinCapeLayer {

    @Inject(method = "submit", at = @At("HEAD"), cancellable = true)
    private void minecraftcapes$renderCape(class_4587 poseStack, class_11659 submitNodeCollector, int packedLight, class_10055 renderState, float limbSwing, float limbSwingAmount, CallbackInfo ci) {
        if (!(renderState instanceof ExtendedRenderState extended) || extended.minecraftcapes$isCapeEnabled()) return;
        ci.cancel();
    }
}
