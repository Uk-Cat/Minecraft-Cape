package net.minecraftcapes.mixin.common;

import net.minecraft.class_640;
import net.minecraft.class_8685;
import net.minecraftcapes.player.DownloadManager;
import net.minecraftcapes.player.PlayerHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

@Mixin(class_640.class)
public class MixinPlayerInfo {

    @Inject(method = "getSkin", at = @At("RETURN"), cancellable = true)
    private void minecraftcapes$getSkin(CallbackInfoReturnable<class_8685> cir) {
        UUID uuid = ((class_640)(Object)this).method_2966().id();
        PlayerHandler handler = PlayerHandler.getOrCreate(uuid);

        if (handler.hasInfo()) {
            cir.setReturnValue(handler.getSkin(cir.getReturnValue()));
        } else {
            DownloadManager.prepareDownload(handler);
        }
    }
}
