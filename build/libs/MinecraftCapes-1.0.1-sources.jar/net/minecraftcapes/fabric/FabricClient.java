package net.minecraftcapes.fabric;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_304;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

import net.minecraftcapes.MinecraftCapes;
import net.minecraftcapes.gui.MenuScreen;

public class FabricClient implements ClientModInitializer {

    private static class_304 keyMapping;

    @Override
    public void onInitializeClient() {
        MinecraftCapes.onEnable(FabricLoader.getInstance().getConfigDir());

        keyMapping = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.minecraftcapes.gui",
                GLFW.GLFW_KEY_J,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (keyMapping.method_1436()) {
                class_310.method_1551().method_1507(new MenuScreen(class_310.method_1551().field_1755));
            }
        });
    }
}
