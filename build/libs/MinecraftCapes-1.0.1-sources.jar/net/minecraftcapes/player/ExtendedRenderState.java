package net.minecraftcapes.player;

import net.minecraft.class_2960;

public interface ExtendedRenderState {
    boolean minecraftcapes$isCapeEnabled();
    void minecraftcapes$setCapeEnabled(boolean enabled);

    boolean minecraftcapes$isCapeGlint();
    void minecraftcapes$setCapeGlint(boolean glint);

    boolean minecraftcapes$isEarsEnabled();
    void minecraftcapes$setEarsEnabled(boolean enabled);

    class_2960 minecraftcapes$getEarsTexture();
    void minecraftcapes$setEarsTexture(class_2960 texture);
}
