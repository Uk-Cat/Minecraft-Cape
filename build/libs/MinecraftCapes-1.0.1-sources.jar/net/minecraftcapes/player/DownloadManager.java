package net.minecraftcapes.player;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import net.minecraft.class_1011;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraftcapes.MinecraftCapes;

public class DownloadManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("minecraftcapes");
    private static final HttpClient CLIENT = HttpClient.newHttpClient();
    private static final String CAPE_BASE_URL = "https://raw.githubusercontent.com/Uk-Cat/Minecraft-Cape/main/Capes/";

    public static void prepareDownload(PlayerHandler playerHandler) {
        class_156.method_18349().execute(() -> {
            try {
                String uuidStr = playerHandler.getUuidString();
                String url = CAPE_BASE_URL + uuidStr + ".png";
                class_1011 capeImage = downloadOrLoad(url, "capes", uuidStr);
                if (capeImage != null) {
                    class_310.method_1551().execute(() -> playerHandler.applyCape(capeImage));
                    playerHandler.setInfo(true);
                    LOGGER.info("Loaded cape for {}", uuidStr);
                }
            } catch (Exception e) {
                LOGGER.error("Failed to load cape for {}", playerHandler.getUuidString(), e);
            }
        });
    }

    private static class_1011 downloadOrLoad(String url, String type, String uuidStr) throws IOException {
        Path cacheDir = MinecraftCapes.configDir.resolve(type);
        Files.createDirectories(cacheDir);

        String hash = hashString(uuidStr);
        String prefix = hash.substring(0, 2);
        Path cacheFile = cacheDir.resolve(prefix).resolve(uuidStr + ".png");

        if (Files.exists(cacheFile)) {
            try {
                return class_1011.method_4309(Files.newInputStream(cacheFile));
            } catch (IOException e) {
                Files.deleteIfExists(cacheFile);
            }
        }

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();
            HttpResponse<InputStream> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofInputStream());
            if (response.statusCode() == 200) {
                Files.createDirectories(cacheFile.getParent());
                try (InputStream in = response.body()) {
                    Files.copy(in, cacheFile);
                }
                return class_1011.method_4309(Files.newInputStream(cacheFile));
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return null;
    }

    private static String hashString(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes());
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException e) {
            return input;
        }
    }
}
