package net.minecraftcapes.player;

import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8685;
import net.minecraftcapes.config.MinecraftCapesConfig;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PlayerHandler {
    private static final Map<UUID, PlayerHandler> HANDLERS = new ConcurrentHashMap<>();
    private static final long FRAME_TIME = 100L;

    private final UUID uuid;
    private boolean hasInfo = false;
    private boolean hasStaticCape = false;
    private boolean hasAnimatedCape = false;
    private boolean hasEars = false;
    private boolean hasCapeGlint = false;
    private boolean upsideDown = false;

    private class_1011 staticCapeImage;
    private java.util.Map<Integer, class_1011> animatedCape;
    private int lastFrame = 0;
    private long lastFrameTime = 0;
    private class_2960 cachedCapeLocation;

    public PlayerHandler(UUID uuid) {
        this.uuid = uuid;
    }

    public static PlayerHandler getOrCreate(UUID uuid) {
        return HANDLERS.computeIfAbsent(uuid, PlayerHandler::new);
    }

    public static Map<UUID, PlayerHandler> getAll() {
        return HANDLERS;
    }

    public static void clearAll() {
        HANDLERS.values().forEach(h -> {
            if (h.staticCapeImage != null) h.staticCapeImage.close();
            if (h.animatedCape != null) h.animatedCape.values().forEach(class_1011::close);
        });
        HANDLERS.clear();
    }

    public boolean hasInfo() { return hasInfo; }
    public boolean hasCapeGlint() { return hasCapeGlint; }
    public boolean isUpsideDown() { return upsideDown; }

    public class_8685 getSkin(class_8685 original) {
        if (!hasInfo || !MinecraftCapesConfig.isCapeVisible()) return original;
        class_2960 capeLocation = getCapeLocation();
        if (capeLocation == null) return original;
        return new class_8685(
                original.comp_1626(),
                new class_12079.class_10726(capeLocation),
                new class_12079.class_10726(capeLocation),
                original.comp_1629(),
                original.comp_1630()
        );
    }

    public class_2960 getCapeLocation() {
        if (hasAnimatedCape) {
            return getFrame();
        }
        return cachedCapeLocation;
    }

    private class_2960 getFrame() {
        long now = System.currentTimeMillis();
        if (now - lastFrameTime >= FRAME_TIME) {
            lastFrame = (lastFrame + 1) % animatedCape.size();
            lastFrameTime = now;
        }
        return class_2960.method_60655("minecraftcapes", "capes/" + uuid + "/" + lastFrame);
    }

    public void applyCape(class_1011 image) {
        int width = image.method_4307();
        int height = image.method_4323();
        boolean animated = height > width / 2;

        if (animated) {
            applyAnimatedCape(image, width, height);
        } else {
            applyStaticCape(image);
        }
    }

    private void applyStaticCape(class_1011 image) {
        String name = "cape_" + uuid;
        class_1043 texture = new class_1043(() -> name, image);
        class_2960 location = class_2960.method_60655("minecraftcapes", name);
        class_310.method_1551().method_1531().method_4616(location, texture);
        cachedCapeLocation = location;
        hasStaticCape = true;
        hasAnimatedCape = false;
        staticCapeImage = image;
    }

    private void applyAnimatedCape(class_1011 sheet, int width, int height) {
        int frameHeight = width / 2;
        int frameCount = height / frameHeight;
        animatedCape = new java.util.HashMap<>();

        for (int i = 0; i < frameCount; i++) {
            class_1011 frame = new class_1011(width, frameHeight, true);
            for (int y = 0; y < frameHeight; y++) {
                for (int x = 0; x < width; x++) {
                    frame.method_61941(x, y, sheet.method_61940(x, i * frameHeight + y));
                }
            }
            String name = "cape_" + uuid + "_" + i;
            class_1043 texture = new class_1043(() -> name, frame);
            class_2960 location = class_2960.method_60655("minecraftcapes", name);
            class_310.method_1551().method_1531().method_4616(location, texture);
            animatedCape.put(i, frame);
            if (i == 0) cachedCapeLocation = location;
        }
        hasAnimatedCape = true;
        hasStaticCape = false;
    }

    public void setInfo(boolean hasInfo) { this.hasInfo = hasInfo; }
    public void setCapeGlint(boolean glint) { this.hasCapeGlint = glint; }
    public void setUpsideDown(boolean upsideDown) { this.upsideDown = upsideDown; }

    public void reloadProfile() {
        DownloadManager.prepareDownload(this);
    }

    public String getUuidString() {
        return uuid.toString().replace("-", "");
    }
}
