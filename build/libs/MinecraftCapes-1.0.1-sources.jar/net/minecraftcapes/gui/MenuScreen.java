package net.minecraftcapes.gui;

import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5676;
import net.minecraft.class_8667;
import net.minecraftcapes.config.MinecraftCapesConfig;
import net.minecraftcapes.player.PlayerHandler;

import java.util.List;
import java.util.function.Consumer;

public class MenuScreen extends class_437 {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;

    private final class_437 parent;

    public MenuScreen(class_437 parent) {
        super(class_2561.method_43471("gui.minecraftcapes.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        class_8667 layout = class_8667.method_52741().method_52735(4);

        layout.method_52736(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.open_website"),
                btn -> class_156.method_668().method_670("https://minecraftcapes.net")
        ).method_46432(BUTTON_WIDTH).method_46431());

        layout.method_52736(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.reload_profile"),
                btn -> {
                    PlayerHandler handler = PlayerHandler.getOrCreate(class_310.method_1551().method_1548().method_44717());
                    handler.setInfo(false);
                    handler.reloadProfile();
                }
        ).method_46432(BUTTON_WIDTH).method_46431());

        layout.method_52736(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.reload_all"),
                btn -> PlayerHandler.clearAll()
        ).method_46432(BUTTON_WIDTH).method_46431());

        layout.method_52736(class_5676.method_32614(MinecraftCapesConfig.isCapeVisible())
                .method_32616()
                .method_32617(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, class_2561.method_43471("button.minecraftcapes.cape_visible"),
                        (btn, val) -> MinecraftCapesConfig.setCapeVisible(val)));

        layout.method_52736(class_5676.method_32614(MinecraftCapesConfig.isEarsVisible())
                .method_32616()
                .method_32617(0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, class_2561.method_43471("button.minecraftcapes.ears_visible"),
                        (btn, val) -> MinecraftCapesConfig.setEarsVisible(val)));

        layout.method_52736(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.discord"),
                btn -> class_156.method_668().method_670("https://discord.gg/minecraftcapes")
        ).method_46432(BUTTON_WIDTH).method_46431());

        layout.method_52736(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.github"),
                btn -> class_156.method_668().method_670("https://github.com/Uk-Cat/Minecraft-Cape")
        ).method_46432(BUTTON_WIDTH).method_46431());

        layout.method_52736(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.website"),
                btn -> class_156.method_668().method_670("https://minecraftcapes.net")
        ).method_46432(BUTTON_WIDTH).method_46431());

        layout.method_48222();
        layout.method_46421((this.field_22789 - layout.method_25368()) / 2);
        layout.method_46419(40);
        layout.method_48206(this::method_37063);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);
        graphics.method_27534(field_22793, field_22785, this.field_22789 / 2, 8, 0xFFFFFF);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(parent);
    }
}