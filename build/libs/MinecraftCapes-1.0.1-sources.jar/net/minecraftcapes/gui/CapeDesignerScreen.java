package net.minecraftcapes.gui;

import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CapeDesignerScreen extends class_437 {
    private final class_437 parent;
    private boolean openedBrowser = false;

    public CapeDesignerScreen(class_437 parent) {
        super(class_2561.method_43471("gui.minecraftcapes.designer.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        LocalDesignerServer.start();
        if (!openedBrowser) {
            class_156.method_668().method_670(LocalDesignerServer.getUrl());
            openedBrowser = true;
        }

        int btnW = 150;
        int btnH = 20;
        int centerX = field_22789 / 2;
        int centerY = field_22790 / 2;

        method_37063(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.designer"),
                btn -> class_156.method_668().method_670(LocalDesignerServer.getUrl())
        ).method_46434(centerX - btnW / 2, centerY + 10, btnW, btnH).method_46431());

        method_37063(class_4185.method_46430(
                class_2561.method_43471("button.minecraftcapes.designer.save"),
                btn -> method_25419()
        ).method_46434(centerX - btnW / 2, centerY + 35, btnW, btnH).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(graphics, mouseX, mouseY, partialTick);

        int centerX = field_22789 / 2;
        int centerY = field_22790 / 2;

        graphics.method_27534(field_22793, field_22785, centerX, centerY - 50, 0xFFFFFF);
        graphics.method_25300(field_22793, "Cape Creator has been opened in your web browser.", centerX, centerY - 25, 0xAAAAAA);
        graphics.method_25300(field_22793, "Use Pencil, Eraser, Fill & more to design your cape. Save & Upload when done.", centerX, centerY - 12, 0x888888);
    }

    @Override
    public void method_25419() {
        LocalDesignerServer.stop();
        class_310.method_1551().method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
