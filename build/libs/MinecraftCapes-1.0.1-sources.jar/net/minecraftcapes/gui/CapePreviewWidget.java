package net.minecraftcapes.gui;

import net.minecraft.class_1011;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public class CapePreviewWidget extends class_339 {
    private static final int HALF_WIDTH = 32;
    private static final int HALF_HEIGHT = 32;
    private static final int LABEL_HEIGHT = 10;
    private static final int SPACING = 6;

    private final int previewScale;
    private class_1011 sourceImage;

    public CapePreviewWidget(int x, int y, int scale) {
        super(x, y, HALF_WIDTH * scale * 2 + SPACING + 4, LABEL_HEIGHT + HALF_HEIGHT * scale + 4, class_2561.method_43473());
        this.previewScale = scale;
    }

    public void setSourceImage(class_1011 image) {
        this.sourceImage = image;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int x = method_46426() + 2;
        int y = method_46427() + 2;
        var font = class_310.method_1551().field_1772;

        int frontW = HALF_WIDTH * previewScale;
        int backW = HALF_WIDTH * previewScale;
        int totalW = frontW + SPACING + backW;

        graphics.method_25294(x - 2, y - 2, x + totalW + 2, y + LABEL_HEIGHT + HALF_HEIGHT * previewScale + 6, 0xFF444444);
        graphics.method_25294(x - 1, y - 1, x + totalW + 1, y + LABEL_HEIGHT + HALF_HEIGHT * previewScale + 5, 0x66000000);

        graphics.method_25303(font, "Front", x + (frontW - font.method_1727("Front")) / 2, y, 0xFFFFFF);
        graphics.method_25303(font, "Back", x + frontW + SPACING + (backW - font.method_1727("Back")) / 2, y, 0xFFFFFF);

        int imageY = y + LABEL_HEIGHT + 2;
        renderHalf(graphics, x, imageY, 0, false);
        renderHalf(graphics, x + frontW + SPACING, imageY, HALF_WIDTH, true);

        graphics.method_25294(x - 2, y + LABEL_HEIGHT + 1, x + totalW + 2, y + LABEL_HEIGHT + 2, 0xFF444444);

        graphics.method_25294(x - 2, imageY - 1, x - 1, imageY + HALF_HEIGHT * previewScale + 1, 0xFF444444);
        graphics.method_25294(x + totalW + 1, imageY - 1, x + totalW + 2, imageY + HALF_HEIGHT * previewScale + 1, 0xFF444444);
        graphics.method_25294(x - 2, imageY + HALF_HEIGHT * previewScale, x + totalW + 2, imageY + HALF_HEIGHT * previewScale + 1, 0xFF444444);
    }

    private void renderHalf(class_332 graphics, int startX, int startY, int sourceOffset, boolean flip) {
        for (int py = 0; py < HALF_HEIGHT; py++) {
            for (int px = 0; px < HALF_WIDTH; px++) {
                int sx = flip ? HALF_WIDTH - 1 - px : px;
                int abgr = 0;
                if (sourceImage != null && sx + sourceOffset < sourceImage.method_4307() && py < sourceImage.method_4323()) {
                    abgr = sourceImage.method_61940(sx + sourceOffset, py);
                }
                int a = (abgr >> 24) & 0xFF;
                int color;
                if (a == 0) {
                    boolean white = ((px + py) & 1) == 0;
                    color = white ? 0xFF2B2B2B : 0xFF353535;
                } else {
                    int b = (abgr >> 16) & 0xFF;
                    int g = (abgr >> 8) & 0xFF;
                    int r = abgr & 0xFF;
                    color = 0xFF000000 | (r << 16) | (g << 8) | b;
                }
                graphics.method_25294(startX + px * previewScale, startY + py * previewScale,
                        startX + px * previewScale + previewScale, startY + py * previewScale + previewScale, color);
            }
        }

        for (int px = 1; px < HALF_WIDTH; px++) {
            graphics.method_25294(startX + px * previewScale - 1, startY, startX + px * previewScale, startY + HALF_HEIGHT * previewScale, 0x22000000);
        }
        for (int py = 1; py < HALF_HEIGHT; py++) {
            graphics.method_25294(startX, startY + py * previewScale - 1, startX + HALF_WIDTH * previewScale, startY + py * previewScale, 0x22000000);
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
    }
}
