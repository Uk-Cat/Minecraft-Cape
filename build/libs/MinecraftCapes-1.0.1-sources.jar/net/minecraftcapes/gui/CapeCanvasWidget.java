package net.minecraftcapes.gui;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public class CapeCanvasWidget extends class_339 {
    private static final int CANVAS_WIDTH = 64;
    private static final int CANVAS_HEIGHT = 32;
    private static final int MIN_SCALE = 4;
    private static final int MAX_SCALE = 16;

    private final class_1011 image;
    private int scale = 8;
    private boolean mirrorMode = false;
    private Tool currentTool = Tool.PENCIL;
    private int selectedColor = 0xFFFFFFFF;
    private boolean dragging = false;
    private int lastPixelX = -1;
    private int lastPixelY = -1;

    private final List<int[]> undoStack = new ArrayList<>();
    private final List<int[]> redoStack = new ArrayList<>();

    private Runnable onImageChanged;

    public enum Tool {
        PENCIL, ERASER, FILL, EYEDROPPER
    }

    public CapeCanvasWidget(int x, int y) {
        super(x, y, CANVAS_WIDTH * 8, CANVAS_HEIGHT * 8, class_2561.method_43473());
        this.image = new class_1011(CANVAS_WIDTH, CANVAS_HEIGHT, true);
        clearImage();
        saveUndoState();
    }

    public void setOnImageChanged(Runnable onImageChanged) {
        this.onImageChanged = onImageChanged;
    }

    public class_1011 getImage() {
        return image;
    }

    public void loadImage(class_1011 newImage) {
        for (int y = 0; y < CANVAS_HEIGHT; y++) {
            for (int x = 0; x < CANVAS_WIDTH; x++) {
                image.method_61941(x, y, newImage.method_61940(x, y));
            }
        }
        undoStack.clear();
        redoStack.clear();
        saveUndoState();
        if (onImageChanged != null) onImageChanged.run();
    }

    public void clearImage() {
        for (int y = 0; y < CANVAS_HEIGHT; y++) {
            for (int x = 0; x < CANVAS_WIDTH; x++) {
                image.method_61941(x, y, 0);
            }
        }
    }

    private void saveUndoState() {
        int[] pixels = new int[CANVAS_WIDTH * CANVAS_HEIGHT];
        for (int y = 0; y < CANVAS_HEIGHT; y++) {
            for (int x = 0; x < CANVAS_WIDTH; x++) {
                pixels[y * CANVAS_WIDTH + x] = image.method_61940(x, y);
            }
        }
        undoStack.add(pixels);
    }

    public void undo() {
        if (undoStack.size() <= 1) return;
        int[] current = new int[CANVAS_WIDTH * CANVAS_HEIGHT];
        for (int y = 0; y < CANVAS_HEIGHT; y++) {
            for (int x = 0; x < CANVAS_WIDTH; x++) {
                current[y * CANVAS_WIDTH + x] = image.method_61940(x, y);
            }
        }
        redoStack.add(current);

        undoStack.remove(undoStack.size() - 1);
        int[] restore = undoStack.get(undoStack.size() - 1);
        for (int y = 0; y < CANVAS_HEIGHT; y++) {
            for (int x = 0; x < CANVAS_WIDTH; x++) {
                image.method_61941(x, y, restore[y * CANVAS_WIDTH + x]);
            }
        }
        if (onImageChanged != null) onImageChanged.run();
    }

    public void redo() {
        if (redoStack.isEmpty()) return;
        int[] current = new int[CANVAS_WIDTH * CANVAS_HEIGHT];
        for (int y = 0; y < CANVAS_HEIGHT; y++) {
            for (int x = 0; x < CANVAS_WIDTH; x++) {
                current[y * CANVAS_WIDTH + x] = image.method_61940(x, y);
            }
        }
        undoStack.add(current);

        int[] next = redoStack.remove(redoStack.size() - 1);
        for (int y = 0; y < CANVAS_HEIGHT; y++) {
            for (int x = 0; x < CANVAS_WIDTH; x++) {
                image.method_61941(x, y, next[y * CANVAS_WIDTH + x]);
            }
        }
        if (onImageChanged != null) onImageChanged.run();
    }

    public void setScale(int scale) {
        this.scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale));
        method_25358(CANVAS_WIDTH * this.scale);
        method_53533(CANVAS_HEIGHT * this.scale);
    }

    public int getScale() { return scale; }

    public void setCurrentTool(Tool tool) { this.currentTool = tool; }
    public Tool getCurrentTool() { return currentTool; }

    public void setSelectedColor(int color) { this.selectedColor = color; }
    public int getSelectedColor() { return selectedColor; }

    public void setMirrorMode(boolean mirror) { this.mirrorMode = mirror; }
    public boolean isMirrorMode() { return mirrorMode; }

    private int getMirrorX(int x) {
        return CANVAS_WIDTH - 1 - x;
    }

    private void setPixel(int x, int y, int color) {
        if (x < 0 || x >= CANVAS_WIDTH || y < 0 || y >= CANVAS_HEIGHT) return;
        image.method_61941(x, y, color);
        if (mirrorMode) {
            int mx = getMirrorX(x);
            image.method_61941(mx, y, color);
        }
    }

    private int getPixel(int x, int y) {
        if (x < 0 || x >= CANVAS_WIDTH || y < 0 || y >= CANVAS_HEIGHT) return 0;
        return image.method_61940(x, y);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean used) {
        if (!method_25405(event.comp_4798(), event.comp_4799())) return false;
        if (event.method_74245() != 0) return false;

        dragging = true;
        int px = (int) ((event.comp_4798() - method_46426()) / scale);
        int py = (int) ((event.comp_4799() - method_46427()) / scale);

        if (px >= 0 && px < CANVAS_WIDTH && py >= 0 && py < CANVAS_HEIGHT) {
            saveUndoState();
            redoStack.clear();
            applyTool(px, py);
            lastPixelX = px;
            lastPixelY = py;
            if (onImageChanged != null) onImageChanged.run();
        }
        return true;
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        if (!dragging) return false;

        int px = (int) ((event.comp_4798() - method_46426()) / scale);
        int py = (int) ((event.comp_4799() - method_46427()) / scale);

        if (px >= 0 && px < CANVAS_WIDTH && py >= 0 && py < CANVAS_HEIGHT) {
            if (currentTool == Tool.PENCIL || currentTool == Tool.ERASER) {
                drawLine(lastPixelX, lastPixelY, px, py);
            } else {
                applyTool(px, py);
            }
            lastPixelX = px;
            lastPixelY = py;
            if (onImageChanged != null) onImageChanged.run();
        }
        return true;
    }

    @Override
    public boolean method_25406(class_11909 event) {
        dragging = false;
        lastPixelX = -1;
        lastPixelY = -1;
        return true;
    }

    private void drawLine(int x0, int y0, int x1, int y1) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            applyTool(x0, y0);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) {
                err -= dy;
                x0 += sx;
            }
            if (e2 < dx) {
                err += dx;
                y0 += sy;
            }
        }
    }

    private void applyTool(int px, int py) {
        switch (currentTool) {
            case PENCIL:
                setPixel(px, py, selectedColor);
                break;
            case ERASER:
                setPixel(px, py, 0);
                break;
            case FILL:
                floodFill(px, py, selectedColor);
                break;
            case EYEDROPPER:
                int color = getPixel(px, py);
                if (color != 0) {
                    selectedColor = color;
                }
                break;
        }
    }

    private void floodFill(int startX, int startY, int newColor) {
        int targetColor = getPixel(startX, startY);
        if (targetColor == newColor) return;

        Deque<int[]> stack = new ArrayDeque<>();
        stack.push(new int[]{startX, startY});

        while (!stack.isEmpty()) {
            int[] p = stack.pop();
            int x = p[0];
            int y = p[1];

            if (x < 0 || x >= CANVAS_WIDTH || y < 0 || y >= CANVAS_HEIGHT) continue;
            if (getPixel(x, y) != targetColor) continue;

            setPixel(x, y, newColor);

            stack.push(new int[]{x + 1, y});
            stack.push(new int[]{x - 1, y});
            stack.push(new int[]{x, y + 1});
            stack.push(new int[]{x, y - 1});
        }
    }

    private static int abgrToRgba(int abgr) {
        int a = (abgr >> 24) & 0xFF;
        int b = (abgr >> 16) & 0xFF;
        int g = (abgr >> 8) & 0xFF;
        int r = abgr & 0xFF;
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int x = method_46426();
        int y = method_46427();
        int w = method_25368();
        int h = method_25364();

        int borderColor = method_25370() ? 0xFF50A6FF : 0xFF2C2C2C;
        graphics.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, borderColor);

        int checkerSize = scale / 2;
        if (checkerSize < 1) checkerSize = 1;

        for (int py = 0; py < CANVAS_HEIGHT; py++) {
            for (int px = 0; px < CANVAS_WIDTH; px++) {
                int abgr = image.method_61940(px, py);
                int a = (abgr >> 24) & 0xFF;
                int pxScreenX = x + px * scale;
                int pxScreenY = y + py * scale;

                if (a == 0) {
                    int c1 = 0xFF2B2B2B;
                    int c2 = 0xFF353535;
                    int mid = checkerSize;
                    graphics.method_25294(pxScreenX, pxScreenY, pxScreenX + mid, pxScreenY + mid, c1);
                    graphics.method_25294(pxScreenX + mid, pxScreenY, pxScreenX + scale, pxScreenY + mid, c2);
                    graphics.method_25294(pxScreenX, pxScreenY + mid, pxScreenX + mid, pxScreenY + scale, c2);
                    graphics.method_25294(pxScreenX + mid, pxScreenY + mid, pxScreenX + scale, pxScreenY + scale, c1);
                } else {
                    graphics.method_25294(pxScreenX, pxScreenY, pxScreenX + scale, pxScreenY + scale, abgrToRgba(abgr));
                }
            }
        }

        if (scale >= 6) {
            int gridColor = 0x22000000;
            for (int px = 1; px < CANVAS_WIDTH; px++) {
                int gx = x + px * scale;
                graphics.method_25294(gx, y, gx + 1, y + h, gridColor);
            }
            for (int py = 1; py < CANVAS_HEIGHT; py++) {
                int gy = y + py * scale;
                graphics.method_25294(x, gy, x + w, gy + 1, gridColor);
            }
        }

        if (method_25367() && mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h) {
            int hx = ((mouseX - x) / scale) * scale;
            int hy = ((mouseY - y) / scale) * scale;
            graphics.method_25294(x + hx, y + hy, x + hx + scale, y + 1, 0xFFFFFFFF);
            graphics.method_25294(x + hx, y + hy, x + 1, y + hy + scale, 0xFFFFFFFF);
            graphics.method_25294(x + hx + scale - 1, y + hy, x + hx + scale, y + hy + scale, 0xFFFFFFFF);
            graphics.method_25294(x + hx, y + hy + scale - 1, x + hx + scale, y + hy + scale, 0xFFFFFFFF);
        }

        if (mirrorMode) {
            int mx = x + (CANVAS_WIDTH / 2) * scale;
            graphics.method_25294(mx - 1, y, mx, y + h, 0x80FF4444);
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
    }

    public void close() {
        image.close();
    }
}
