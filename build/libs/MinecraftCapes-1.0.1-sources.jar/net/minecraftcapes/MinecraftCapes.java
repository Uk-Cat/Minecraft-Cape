package net.minecraftcapes;

import net.minecraft.class_2960;
import net.minecraftcapes.config.MinecraftCapesConfig;

import java.nio.file.Path;

public class MinecraftCapes {
    public static final String MOD_ID = "minecraftcapes";
    public static final String MINECRAFT_VERSION = "1.21.11";
    public static Path configDir;

    public static void onEnable(Path configDirPath) {
        configDir = configDirPath.resolve(MOD_ID);
        MinecraftCapesConfig.loadConfig(configDir);
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
